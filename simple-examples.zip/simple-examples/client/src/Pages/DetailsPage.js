import React from 'react'

export const DetailPage=()=>{
    return(
        <div>
            <h1>Details page</h1>
        </div>
    )
}