import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import CardMedia from '@material-ui/core/CardMedia';
import logo1 from '../assets/iconCreate1.png'
import logo2 from '../assets/iconCreate2.svg'
import logo3 from '../assets/iconCreate3.png'
import logo4 from '../assets/iconCreate4.png'

const useStyles = makeStyles((theme) => ({
    root: {
        display:'flex',
        minWidth: 200,
        height:140,
        borderRadius: 20,
        [theme.breakpoints.down("md")] : {
            maxWidth: '100%' 
            }
      },
      bullet: {
        display: 'inline-block',
        margin: '0 2px',
        transform: 'scale(0.8)',
      },
      title: {
        fontSize: 5,
      },
      details: {
        display: 'flex',
        flexDirection: 'column',
      },
      pos: {
        marginBottom: 12,
      },
      cover: {
        width: '50%'
      },
      content: {
        flex: '1 0 auto',
        fontSize:4
      },
      top:{
          marginTop:70
      }
  }));

export const CreatePage=()=>{
    const classes = useStyles();
    const bull = <span className={classes.bullet}>•</span>;
    return(
        <div className={classes.top}>
         
            {/* I am a container Grid with 1 (8px) spacing*/}
            <Grid container spacing={3} >
                <Grid container item xs={12} sm={6} md={3}>
                <Card className={classes.root}>
                    <div className={classes.details}>
                        <CardContent className={classes.content}>
                            <Typography component="h5" variant="h5">
                                Беззалоговый кредит наличными
                            </Typography>
                            <Typography variant="subtitle1" color="textSecondary">
                                24/7
                            </Typography>
                        </CardContent>
                    </div>
                    <CardMedia
                        className={classes.cover}
                        image={logo1}
                        title="Live from space album cover"
                    />
                    </Card>
                </Grid>
                <Grid container item xs={12} sm={6} md={3}>
                <Card className={classes.root}>
                    <div className={classes.details}>
                        <CardContent className={classes.content}>
                            <Typography component="h5" variant="h5">
                                Каникулы с Eurasian Bank
                            </Typography>
                            <Typography variant="subtitle1" color="textSecondary">
                                подробнее в отделениях банка
                            </Typography>
                        </CardContent>
                    </div>
                    <CardMedia
                        className={classes.cover}
                        image={logo2}
                        title="Live from space album cover"
                    />
                    </Card>
                </Grid>            
                    <Grid container item xs={12} sm={6} md={3}>
                    <Card className={classes.root}>
                    <div className={classes.details}>
                        <CardContent className={classes.content}>
                            <Typography component="h5" variant="h5">
                               Как работает Eurasian Pay?
                            </Typography>
                            <Typography variant="subtitle1" color="textSecondary">
                                узнать подробнее
                            </Typography>
                        </CardContent>
                    </div>
                    <CardMedia
                        className={classes.cover}
                        image={logo3}
                        title="Live from space album cover"
                    />
                    </Card>
                </Grid>
                <Grid container item xs={12} sm={6} md={3}>
                <Card className={classes.root}>
                    <div className={classes.details}>
                        <CardContent className={classes.content}>
                            <Typography component="h5" variant="h5">
                                Как работает Eurasian PayDa
                            </Typography>
                            <Typography variant="subtitle1" color="textSecondary">
                                PayDa карты
                            </Typography>
                        </CardContent>
                    </div>
                    <CardMedia
                        className={classes.cover}
                        image={logo4}
                        title="Live from space album cover"
                    />
                    </Card>
                </Grid>
            </Grid>
        </div>
    )
}