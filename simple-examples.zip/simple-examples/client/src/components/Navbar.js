import React, { useContext } from 'react'
import {NavLink, useHistory} from 'react-router-dom'
import { AuthContext } from '../context/authContext'
import clsx from 'clsx';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import InboxIcon from '@material-ui/icons/MoveToInbox';
import WorkOutlineIcon from '@material-ui/icons/WorkOutline';
import LogOutIcon from '@material-ui/icons/ExitToApp'
import { LinksPage } from '../Pages/LinksPage';
import { CreatePage } from '../Pages/CreatePage';
import { createBrowserHistory } from "history";
import { Router, Route, Link } from "react-router-dom";
import logo from '../assets/logo2.svg'
import BottomNavigation from '@material-ui/core/BottomNavigation';
import BottomNavigationAction from '@material-ui/core/BottomNavigationAction';
import FolderIcon from '@material-ui/icons/Folder';
import RestoreIcon from '@material-ui/icons/Restore';
import FavoriteIcon from '@material-ui/icons/Favorite';
import LocationOnIcon from '@material-ui/icons/LocationOn';


const drawerWidth = 240;
const history = createBrowserHistory();

const useStyles = makeStyles((theme) => ({
    root: {
      display: 'flex'
    },
    appBar: {
      zIndex: theme.zIndex.drawer + 1,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      backgroundColor: 'white',
      [theme.breakpoints.down('sm')]: {
        display:'none'
      },
    },
    appBarShift: {
      marginLeft: drawerWidth,
      width: `calc(100% - ${drawerWidth}px)`,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    menuButton: {
      marginRight: 36
    },
    hide: {
      display: 'none',
    },
    drawer: {
      width: drawerWidth,
      flexShrink: 0,
      whiteSpace: 'nowrap',
      [theme.breakpoints.down('sm')]: {
        alignItems:'bottom'
      },
      
    },
    drawerOpen: {
      width: drawerWidth,
      transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    },
    drawerClose: {
      transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      overflowX: 'hidden',
      width: theme.spacing(7) + 1,
      [theme.breakpoints.up('sm')]: {
        width: theme.spacing(9) + 1,
      },
    },
    toolbar: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      padding: theme.spacing(0, 1),
      ...theme.mixins.toolbar,
      [theme.breakpoints.down('sm')]: {
        display:'none'
      },
    },
    logo: {
        maxWidth: 100,
      },
    content: {
      flexGrow: 1,
      padding: theme.spacing(5),
    },
    list:{
        backgroundColor:'white',
        color: 'black',
    },
    menuIcon:{
    color:'black'
    }
  }));

  

export const Navbar =()=>{
    const auth = useContext(AuthContext)
    const history = useHistory()
    const logoutHandler = event =>{
        event.preventDefault()
        auth.logout()
        history.push('/')
    }
    const classes = useStyles();
    const theme = useTheme();
    const [open, setOpen] = React.useState(false);
    const [value, setValue] = React.useState('recents');
  
    const handleDrawerOpen = () => {
      setOpen(true);
    };

    const handleChange = (event, newValue) => {
      setValue(newValue);
    };

    const handleDrawerClose = () => {
      setOpen(false);
    };

    const ListItemLink=(props) =>{
        return <ListItem button component="a" {...props} />;
      }
    return(
        <Router history={history}>
            <div className={classes.root}>
        <CssBaseline />
        <AppBar
        elevation={3}
        boxShadow={3}
          position="fixed"
          className={clsx(classes.appBar, {
            [classes.appBarShift]: open,
          })}
        >
            
          <Toolbar>
       
          <IconButton
              color="inherit"
              aria-label="open drawer"
              onClick={handleDrawerOpen}
              edge="start"
              className={clsx(classes.menuButton, {
                [classes.hide]: open,
              })}
            >
               <MenuIcon className={classes.menuIcon}/>
            </IconButton>
            <img src={logo} alt="EB!" className={classes.logo} />
          </Toolbar>
        </AppBar>
        <Drawer
          variant="permanent"
          anchor="top"
          className={clsx(classes.drawer, {
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          })}
          classes={{
            paper: clsx({
              [classes.drawerOpen]: open,
              [classes.drawerClose]: !open,
            }),
          }}
        >
          <div className={classes.toolbar}>
            <IconButton onClick={handleDrawerClose}>
              {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
            </IconButton>
          </div>
          <Divider />
          
          <List component="nav" className={classes.list}>
            <ListItem
                button
                key="create"
                component={NavLink} to="/create"
                >
                <ListItemIcon> <WorkOutlineIcon /></ListItemIcon>
                <ListItemText primary="Main Page" />
            </ListItem>
           </List>
           <List component="nav" className={classes.list}>
                <ListItem
                    button
                    key="links"
                    component={NavLink} to="/links"
                    >
                        <ListItemIcon> <InboxIcon /></ListItemIcon>
                    <ListItemText primary="Loan Page" />
                </ListItem>
            </List>
            <List component="nav" >
                <ListItem
                    button
                    key="logout"
                    onClick={logoutHandler}
                    >
                    <ListItemIcon> <LogOutIcon /></ListItemIcon>
                    <ListItemText primary="log out" />
                </ListItem>
            </List>
          <Divider />
        </Drawer>
        
        <main className={classes.content}>
            <Route  path="/links" component={LinksPage} />
            <Route exact path="/create" component={CreatePage} />
        </main>
      </div>

        </Router>
        
        
    )
}